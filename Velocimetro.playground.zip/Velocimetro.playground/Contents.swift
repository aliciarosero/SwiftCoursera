//: Playground - noun: a place where people can play
// Autor: Alicia Rosero

import UIKit

enum Velocidades: Int {
    case Apagado = 0, VelocidadBaja = 20, VelocidadMedia = 50, VelocidadAlta = 120
    
    
    init(velocidadInicial : Velocidades) {
        self = velocidadInicial
    }
}


class Auto {
    var velocidad: Velocidades
    
    init()
    {
        velocidad = Velocidades(velocidadInicial: Velocidades.Apagado)
    }
    func cambioDeVelocidad() -> (actual: Int, velocidadEnCadena: String) {
        let actual = velocidad.rawValue
        var cadena: String = " "
        switch velocidad {
        case .Apagado:
            velocidad = .VelocidadBaja
            cadena = "Apagado"
        case .VelocidadBaja:
            velocidad = .VelocidadMedia
            cadena = "Velocidad baja"
        case .VelocidadMedia:
            velocidad = .VelocidadAlta
            cadena = "Velocidad media"
        case .VelocidadAlta:
            velocidad = .VelocidadMedia
            cadena = "Velocidad alta"
        }
        return(actual, cadena)
    }
}
var auto = Auto()
var velocidadActual: Int
var leyenda: String

for index in 1...20{
    (velocidadActual, leyenda) = auto.cambioDeVelocidad()
    print("\(velocidadActual), \(leyenda)")
}


